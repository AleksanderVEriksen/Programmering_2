package model;

public class fugler extends animal {
    private boolean rovfugl;
    private boolean kanDenFly;

    public fugler(){};
    public fugler(String name, String latin, boolean rovfugl, boolean kanDenFly){
        super(name, latin);
        this.rovfugl = rovfugl;
        this.kanDenFly = kanDenFly;
    }

    @Override
    public String toString() {
        return  super.toString() +
                ", rovfugl = " + rovfugl +
                ", kanDenFly = " + kanDenFly ;
    }

    public boolean isRovfugl() {
        return rovfugl;
    }

    public void setRovfugl(boolean rovfugl) {
        this.rovfugl = rovfugl;
    }

    public boolean isKanDenFly() {
        return kanDenFly;
    }

    public void setKanDenFly(boolean kanDenFly) {
        this.kanDenFly = kanDenFly;
    }
}
