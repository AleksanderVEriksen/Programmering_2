package model;

public class amfibier extends animal {
    private int antall_bein;
    private boolean giftig;


    public amfibier(){};
    public amfibier(String name, String latinName, int antall_bein, boolean giftig) {
        super(name, latinName);
        this.antall_bein = antall_bein;
        this.giftig = giftig;
    }

    @Override
    public String toString() {
        return      super.toString() +
                ", antall_bein = " + antall_bein +
                ", giftig = " + giftig ;
    }

    public int getAntall_bein() {
        return antall_bein;
    }

    public void setAntall_bein(int antall_bein) {
        this.antall_bein = antall_bein;
    }

    public boolean isGiftig() {
        return giftig;
    }

    public void setGiftig(boolean giftig) {
        this.giftig = giftig;
    }
}
