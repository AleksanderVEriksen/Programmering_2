package model;

import model.animal;

public class virvellose extends animal {
    private boolean vannBasert;
    private int antall_bein;

    public virvellose(){};
    public virvellose(String name, String latinName, boolean vannBasert, int antall_bein) {
        super(name, latinName);
        this.vannBasert = vannBasert;
        this.antall_bein = antall_bein;
    }

    @Override
    public String toString() {
        return   super.toString() +
                ", vannBasert = " + vannBasert +
                ", antall_bein = " + antall_bein ;
    }

    public boolean isVannBasert() {
        return vannBasert;
    }

    public void setVannBasert(boolean vannBasert) {
        this.vannBasert = vannBasert;
    }

    public int getAntall_bein() {
        return antall_bein;
    }

    public void setAntall_bein(int antall_bein) {
        this.antall_bein = antall_bein;
    }
}
