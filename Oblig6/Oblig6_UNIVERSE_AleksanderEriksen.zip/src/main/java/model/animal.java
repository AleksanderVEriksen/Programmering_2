package model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

@JsonTypeInfo(
        use = JsonTypeInfo.Id.NAME,
        include = JsonTypeInfo.As.PROPERTY,
        property = "type")
@JsonSubTypes({
        @JsonSubTypes.Type(value = amfibier.class, name = "amfibi"),
        @JsonSubTypes.Type(value = virvellose.class, name = "virvellos"),
        @JsonSubTypes.Type(value = fugler.class, name = "fugl")

})
public abstract class animal implements Comparable<animal>{
    private String name;
    private String latinName;

    public animal(){};
    public animal(String name, String latinName) {
        this.name = name;
        this.latinName = latinName;
    }
    @JsonIgnore
    @Override
    public String toString() {
        return "name='" + name + '\'' +
                ", Latin Name='" + latinName + '\'';
    }
    @JsonIgnore
    @Override
    public int compareTo(animal o) {
        return this.getName().compareTo(o.getName());
    }

    public String getLatinName() {
        return latinName;
    }

    public void setLatinName(String latinName) {
        this.latinName = latinName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
