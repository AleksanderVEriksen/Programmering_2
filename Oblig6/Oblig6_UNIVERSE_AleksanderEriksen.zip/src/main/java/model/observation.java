package model;


import java.time.LocalDateTime;


public class observation implements Comparable<observation> {
    private int id;
    private String name;
    private animal art;
    private Lokasjon lokasjon;
    private LocalDateTime timestamp;
    private int antall;
    private String bilde;
    private String kommentar;

    public observation(){};
    public observation(int id, String name, animal art ,Lokasjon lokasjon, LocalDateTime timestamp, int antall, String bilde, String kommentar){
        this.id = id;
        this.name = name;
        this.art = art;
        this.lokasjon = lokasjon;
        this.timestamp = timestamp;
        this.antall = antall;
        this.bilde = bilde;
        this.kommentar = kommentar;
    }

    @Override
    public String toString() {
        return  "name='" + name +
                ", id=" + id + '\'' +
                ",[art = " + art.getClass().getSimpleName() +
                 ",  " + art +
                "],[Lokasjon = " + lokasjon +
                "], timestamp = " + timestamp +
                ", antall = " + antall +
                ", bilde = '" + bilde + '\'' +
                "," + kommentar + '\'';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Lokasjon getLokasjon() {
        return lokasjon;
    }

    public void setLokasjon(Lokasjon lokasjon) {
        this.lokasjon = lokasjon;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }

    public int getAntall() {
        return antall;
    }

    public void setAntall(int antall) {
        this.antall = antall;
    }

    public String getBilde() {
        return bilde;
    }

    public void setBilde(String bilde) {
        this.bilde = bilde;
    }

    public String getKommentar() {
        return kommentar;
    }

    public void setKommentar(String kommentar) {
        this.kommentar = kommentar;
    }

    public animal getArt() {
        return art;
    }

    public void setArt(animal art) {
        this.art = art;
    }

    @Override
    public int compareTo(observation o) {
        return this.getAntall() - o.getAntall();
    }
}
