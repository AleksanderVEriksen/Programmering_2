package model;

public class Planet implements Comparable<Planet> {
    private String name;

    public Planet(){};
    public Planet(String name){

        this.name = name;
    }

    @Override
    public String toString() {
        return  " " + name + '\'';
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public int compareTo(Planet o) {
        return this.getName().compareTo(o.getName());
    }
}
