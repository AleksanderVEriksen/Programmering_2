package model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import model.Biom;
@JsonTypeInfo(
        use = JsonTypeInfo.Id.NAME,
        include = JsonTypeInfo.As.PROPERTY,
        property = "type")
@JsonSubTypes({
        // @JsonSubTypes.Type(value = Lokasjon.class, name = "Lokasjon"),
        @JsonSubTypes.Type(value = Biom.class, name = "biom"),
        @JsonSubTypes.Type(value = Planet.class, name = "planet")

})
public class Lokasjon implements Comparable<Lokasjon> {
    private String name;
    private double lengde;
    private double bredde;
    private Biom biom;
    private Planet planet;

    public Lokasjon(){};
    public Lokasjon(String name, double lengde, double bredde, Biom biom, Planet planet){

        this.name = name;
        this.lengde = lengde;
        this.bredde = bredde;
        this.biom = biom;
        this.planet = planet;

    }
    @JsonIgnore
    @Override
    public String toString() {
        return  name + '\'' +
                ", lengde=" + lengde +
                ", bredde=" + bredde +
                ", biom=" + biom +
                ", planet=" + planet ;
    }
    /*public model.Biom getBiom(String biom){
        for (model.Biom value : bioms) {
            if (value.getName().equals(biom)) {
                return value;
            }
        }
        return null;
    }
    public model.Planet getPlanet(String planet){
        for (model.Planet value : planets) {
            if (value.getName().equals(planet)) {
                return value;
            }
        }
        return null;
    }

    public ArrayList<model.Biom> getBioms() {
        return new ArrayList<>(bioms);
    }

    public ArrayList<model.Planet> getPlanets() {
        return new ArrayList<>(planets);
    }*/

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getLengde() {
        return lengde;
    }

    public void setLengde(double lengde) {
        this.lengde = lengde;
    }

    public double getBredde() {
        return bredde;
    }

    public void setBredde(double bredde) {
        this.bredde = bredde;
    }

    public Biom getBiom() {
        return biom;
    }

    public void setBiom(Biom biom) {
        this.biom = biom;
    }

    public Planet getPlanet() {
        return planet;
    }

    public void setPlanet(Planet planet) {
        this.planet = planet;
    }
    @JsonIgnore
    @Override
    public int compareTo(Lokasjon o) {
        return this.getName().compareTo(o.getName());
    }
}
