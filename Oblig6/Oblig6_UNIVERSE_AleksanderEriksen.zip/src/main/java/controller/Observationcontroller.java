package controller;

import Repository.IObservasjon;
import Repository.ObservasjonRepository;
import Repository.ObservationJSON;
import io.javalin.http.Context;

public class Observationcontroller {
    private IObservasjon repository;

    public Observationcontroller(IObservasjon repository){this.repository = repository;}

    public void getAllObservations(Context context){

        context.json(repository.getAllObservasjon());
    }
}
