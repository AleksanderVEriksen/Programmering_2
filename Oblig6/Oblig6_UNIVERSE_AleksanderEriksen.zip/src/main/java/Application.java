import Repository.ObservasjonRepository;
import Repository.ObservationJSON;
import controller.Observationcontroller;
import io.javalin.Javalin;
import io.javalin.plugin.rendering.vue.VueComponent;

public class Application {
    public static void main(String[] args) {

        Javalin app = Javalin.create().start();
        app.config.enableWebjars();

        ObservasjonRepository repository = new ObservasjonRepository("skriv_Observasjon_Til_JSON.json");
        ObservationJSON json = new ObservationJSON(repository);
        Observationcontroller controller = new Observationcontroller(json);

       // System.out.println("All obs: " + "\n" + repository.getAllObservasjon());

        app.get("/", ctx -> ctx.result("Hello World"));

        app.get("/observations-overview", new VueComponent("observations-overview"));

        app.get("/api/observations",controller::getAllObservations);


    }
}
