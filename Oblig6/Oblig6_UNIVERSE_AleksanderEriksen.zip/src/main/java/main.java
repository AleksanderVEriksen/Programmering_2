import Repository.ObservasjonRepository;
import Repository.ObservationJSON;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import model.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;

public class main {
    public static void main(String[] args) {

        Biom Orken = new Biom("Orken");
        Biom Halvorken = new Biom("Halvorken");
        Biom Tundra = new Biom("Tundra");
        Biom Steppe = new Biom("Steppe");
        Biom Savanne = new Biom("Savanne");
        Biom Mediterrant_biom = new Biom("Meditterant_biom");
        Biom Skog = new Biom("Skog");
        Biom Hav = new Biom("Hav");


        Planet Mercury = new Planet("Mercury");
        Planet Venus = new Planet("Venus");
        Planet Earth = new Planet("Earth");
        Planet Mars = new Planet("Mars");
        Planet Jupiter = new Planet("Jupiter");
        Planet Saturn = new Planet("Saturn");
        Planet Uranus = new Planet("Uranus");
        Planet Neptune = new Planet("Neptune");



        animal maanet = new virvellose("maanet", "etlatinskNavn",true,7);
        animal wtf = new amfibier("Poison_Dart_frog","Dendrobatidae",4,true);
        animal hehe = new virvellose("Snegle","ssss",false,0);
        animal g = new fugler("Måke","Bråkebøtte",false,true);


        Lokasjon lok1 = new Lokasjon("Jaaa",345,456,Hav,Mercury);
        Lokasjon lok2 = new Lokasjon("Frosk",456,456,Skog,Earth);
        Lokasjon lok3 = new Lokasjon("Hypokopus",1200,2,Orken,Mars);
        Lokasjon lok4 = new Lokasjon("Slittsom",0,0,Tundra,Earth);


        observation ob1 = new observation(1,"Ob1",maanet,lok1, LocalDateTime.of(1998,12,23,12,23),3,"BildeString","Vanlig fenomen");
        observation ob2 = new observation(2,"ob2",wtf,lok2,LocalDateTime.of(2003, 6,3,05,43),1,"https://upload.wikimedia.org/wikipedia/commons/0/0e/Blue-poison.dart.frog.and.Yellow-banded.dart.frog.arp.jpg","Veldig farlig!!");
        observation ob3 = new observation(3,"ob3",hehe,lok3,LocalDateTime.of(1993, 11,13,01,12),6,"bilde","Ressurs for fremtiden?");
        observation ob4 = new observation(4,"ob4",g,lok4,LocalDateTime.of(1948, 6,9,07,56),12,"Moak","Skriker hele tiden");
        observation ob5 = new observation(5,"ob5",g,lok4,LocalDateTime.of(1965, 1,31,18,29),12,"Moak","Skriker hele tiden");
        observation ob6 = new observation(6,"ob6",g,lok4,LocalDateTime.of(2011, 2,22,06,43),12,"Moak","Skriker hele tiden");

       // System.out.println(ob1 + "\n" + ob2 + "\n" + ob3 + "\n" + ob4 + "\n" + ob5 + "\n" + ob6 );

        ArrayList<Planet> planets = new ArrayList<>();
        planets.add(Mercury);
        planets.add(Venus);
        planets.add(Earth);
        planets.add(Jupiter);
        planets.add(Saturn);
        planets.add(Uranus);

        //System.out.println(planets);
        Collections.sort(planets);
       // System.out.println(planets);

        ObservasjonRepository allobs = new ObservasjonRepository("skriv_Observasjon_Til_JSON.json");
        ObservationJSON json = new ObservationJSON(allobs);

    }
}
