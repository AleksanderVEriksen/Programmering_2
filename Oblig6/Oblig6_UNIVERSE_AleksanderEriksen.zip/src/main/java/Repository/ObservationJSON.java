package Repository;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import model.Lokasjon;
import model.animal;
import model.observation;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;

public class ObservationJSON implements IObservasjon {
    private ObservasjonRepository obsRep;
    public ArrayList<observation> obsJSON = new ArrayList<>();


    public ObservationJSON(ObservasjonRepository obsRep){
        this.obsRep = obsRep;
        lesJsonfil();
        skrivTilJson();
    }


    public void skrivTilJson(){
        File file = new File(this.obsRep.getFilnavn());
        ObjectMapper objectMapper = new ObjectMapper();

        objectMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS,false);
        objectMapper.registerModule(new JavaTimeModule());

        try {
            objectMapper.writerWithDefaultPrettyPrinter().writeValue(file,obsJSON);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void lesJsonfil() {
        ObjectMapper objectMapper = new ObjectMapper();
        try {

            objectMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS,false);
            objectMapper.registerModule(new JavaTimeModule());

            observation[] lesObservasjon = objectMapper.readValue(new File(this.obsRep.getFilnavn()), observation[].class);

            Collections.addAll(obsJSON, lesObservasjon);

        }catch(JsonParseException | JsonMappingException e){
            e.printStackTrace();
        }catch(IOException e){
            e.printStackTrace();
        }
        System.out.println("JSON read: ");
        for (model.observation observation : obsRep.getAllObservasjon()) {
            System.out.println(observation);
        }

    }

    @Override
    public ArrayList<observation> getAllObservasjon() {
        return obsJSON;
    }

    @Override
    public observation createObservation(int id, String name, animal art, Lokasjon lokasjon, LocalDateTime timestamp, int antall, String bilde, String kommentar) {
        return null;
    }

    @Override
    public void updateObservation(int id, String name, animal art, Lokasjon lokasjon, LocalDateTime timestamp, int antall, String bilde, String kommentar) {

    }

    @Override
    public void deleteObservation(int id) {

    }
}
