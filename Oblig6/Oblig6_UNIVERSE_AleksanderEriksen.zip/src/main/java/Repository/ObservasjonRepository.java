package Repository;

import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import model.*;

import java.lang.Object;
import java.io.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ObservasjonRepository implements  IObservasjon {
    private String filnavn;
    public ArrayList<observation> observations = new ArrayList<>();
    //public ArrayList<observation> jsonread = new ArrayList<>();
    public ArrayList<Lokasjon> lokasjons = new ArrayList<>();



    public ObservasjonRepository(String filnavn){
        this.filnavn = filnavn;

        Biom Orken = new Biom("Orken");
        Biom Halvorken = new Biom("Halvorken");
        Biom Tundra = new Biom("Tundra");
        Biom Steppe = new Biom("Steppe");
        Biom Savanne = new Biom("Savanne");
        Biom Mediterrant_biom = new Biom("Meditterant_biom");
        Biom Skog = new Biom("Skog");
        Biom Hav = new Biom("Hav");

        Planet Mercury = new Planet("Mercury");
        Planet Venus = new Planet("Venus");
        Planet Earth = new Planet("Earth");
        Planet Mars = new Planet("Mars");
        Planet Jupiter = new Planet("Jupiter");
        Planet Saturn = new Planet("Saturn");
        Planet Uranus = new Planet("Uranus");
        Planet Neptune = new Planet("Neptune");

        animal maanet = new virvellose("Jellyfish", "Jellu fishu",true,7);
        animal amfibie = new amfibier("Poison dart frog","Dendrobatidae",4,true);
        animal virvellose = new virvellose("Cat Snail","snogle",false,0);
        animal fugl = new fugler("Moke","Brakebotte",false,true);
        animal Tyler1 = new amfibier("Tuler3","Tulius",2,true);
        animal Hest = new fugler("Flyvehest", "Flyvius hestius",true,true);

        Lokasjon lok1 = new Lokasjon("Røde Hav",345,456,Hav,Mercury);
        Lokasjon lok2 = new Lokasjon("Frosk",456,456,Skog,Earth);
        Lokasjon lok3 = new Lokasjon("Hypokopus",1200,2,Orken,Mars);
        Lokasjon lok4 = new Lokasjon("Ved havet",0,0,Tundra,Earth);
        Lokasjon lok5 = new Lokasjon("USA",345,456,Mediterrant_biom,Earth);
        Lokasjon lok6 = new Lokasjon("Døden",1,23,Steppe,Venus);

        observation ob1 = new observation(1,"Ob1",maanet,lok1, LocalDateTime.of(2019,03,12,17,34),3,"https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fwww.leisurepro.com%2Fblog%2Fwp-content%2Fuploads%2F2017%2F05%2Fshutterstock_480784465-1366x800.jpg&f=1&nofb=1","Vanlig fenomen");
        observation ob2 = new observation(2,"ob2",amfibie,lok2, LocalDateTime.of(2003,6,3,13,33),1,"https://upload.wikimedia.org/wikipedia/commons/0/0e/Blue-poison.dart.frog.and.Yellow-banded.dart.frog.arp.jpg","Veldig farlig!!");
        observation ob3 = new observation(3,"ob3",virvellose,lok3,LocalDateTime.of(1993,11,13,22,12),6,"https://external-content.duckduckgo.com/iu/?u=http%3A%2F%2Forig10.deviantart.net%2F44a3%2Ff%2F2015%2F191%2F8%2F0%2Fcat_snail_by_onyxiscool-d90re9l.jpg&f=1&nofb=1","Potensiell Kjærledyr?");
        observation ob4 = new observation(4,"ob4",fugl,lok4,LocalDateTime.of(1948,6,30,9,12),12,"https://external-content.duckduckgo.com/iu/?u=http%3A%2F%2Fdreamstop.com%2Fwp-content%2Fuploads%2F2016%2F08%2FSeagull-Dream.jpg&f=1&nofb=1","Skriker hele tiden");
        observation ob5 = new observation(5,"ob5",Tyler1,lok5,LocalDateTime.of(1965,1,31,6,12),12,"https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fpbs.twimg.com%2Fmedia%2FCvVEcGbWEAApKXw.jpg&f=1&nofb=1","Skriker hele tiden");
        observation ob6 = new observation(6,"ob6",Hest,lok6,LocalDateTime.of(2011,2,22,2,22),12,"https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fs-media-cache-ak0.pinimg.com%2Foriginals%2F1c%2F37%2Fa8%2F1c37a8213f22e5103a0c500c380678db.jpg&f=1&nofb=1","Den ser kanskje morsom ut, men er kjempe dødelig");

        observations.add(ob1);
        observations.add(ob2);
        observations.add(ob3);
        observations.add(ob4);
        observations.add(ob5);
        observations.add(ob6);

        lokasjons.add(lok1);
        lokasjons.add(lok2);
        lokasjons.add(lok3);
        lokasjons.add(lok4);
        lokasjons.add(lok5);
        lokasjons.add(lok6);
    }


    public void setFilnavn(String filnavn) {
        this.filnavn = filnavn;
    }

    public String getFilnavn() {
        return filnavn;
    }
    public observation getObservationById(int id){
        for (observation ss:observations) {
            if (ss.getId() == (id))
                return ss;
        }
        return null;
    }
    @Override
    public ArrayList<observation> getAllObservasjon() {
        return new ArrayList<>(observations);
    }

    @Override
    public observation createObservation(int id, String name, animal art, Lokasjon lokasjon, LocalDateTime timestamp, int antall, String bilde, String kommentar) {

        return null;
    }

    @Override
    public void updateObservation(int id, String name, animal art, Lokasjon lokasjon, LocalDateTime timestamp, int antall, String bilde, String kommentar) {


    }

    @Override
    public void deleteObservation(int id) {

    }


 /*  public void lesCSV() {


       try (BufferedReader buffleser = new BufferedReader(new FileReader(this.filnavn))){

           String linje;



           while((linje = buffleser.readLine()) != null){
               String[] deler = linje.split(",");
               Lokasjon lokasjon;//, = new Star(deler[2]Double.parseDouble(deler[3]), Double.parseDouble(deler[4]), Double.parseDouble(deler[5]), deler[6])
               dyreart art;

               Observasjon observasjon;


               if (observations.containsKey(deler[0])){
                   observasjon = observations.get(deler[0]);
                   lokasjon = observasjon.getLokasjon();

               }
               else{
                   lokasjon = new Lokasjon();
                   observasjon = new Observasjon(Integer.parseInt(deler[0]), deler[1], art,lokasjon,Long.parseLong(deler[2]),Integer.parseInt(deler[3]),deler[4],deler[5]);
               }
               Planet enplanet = new Planet(deler[7], Double.parseDouble(deler[8]), Double.parseDouble(deler[9]), Double.parseDouble(deler[10]), Double.parseDouble(deler[11]), Double.parseDouble(deler[12]), centerStar, deler[13]);
               planetsystem.addPlanet(enplanet);



               observations.put(deler[0],observasjon );



           }

       }catch(FileNotFoundException fnfe){
           System.out.println(fnfe.getMessage());
       } catch (IOException e) {
           System.out.println(e.getLocalizedMessage());
       }

       // System.out.println(planetSystemOversikt);


   }
    public void skrivCSV() {


        try (BufferedWriter bufretSkriver = new BufferedWriter(new FileWriter("skriv_PlanetSystem_Til_CSV.csv"))) {

            String separator = ",";

            for(Observasjon etplanetsystem : observations.values()) {
                int key=0;
                // System.out.println(etplanetsystem);

                bufretSkriver.write( etplanetsystem.getId()  + separator + etplanetsystem.getName() + separator + "\n" + etplanetsystem.getArt() +
                        separator +  etplanetsystem.getLokasjon() + separator + etplanetsystem.getTimestamp() + separator + etplanetsystem.getAntall() + separator + etplanetsystem.getBilde()
                         + separator + etplanetsystem.getKommentar() + "\n");
                // Skriver et linjeskift
                bufretSkriver.newLine();
            }
        } catch (FileNotFoundException fnfe) {
            // Skriver ut feilmelding om filen ikke finnes
            System.out.println(fnfe.getMessage());
        } catch (IOException ioexc) {
            // skriver ut feilmelding om det oppstår feil ved skriving til fil
            System.out.println(ioexc.getLocalizedMessage());
        }

    }*/



}
