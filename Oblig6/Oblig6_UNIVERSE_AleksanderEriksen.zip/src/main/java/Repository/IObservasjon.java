package Repository;

import model.Lokasjon;
import model.Planet;
import model.animal;
import model.observation;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;

public interface IObservasjon {
    ArrayList<observation> getAllObservasjon();
    //observation getOneSpecificObservasjon(String Observasjon_navn);

    observation createObservation(int id, String name, animal art, Lokasjon lokasjon, LocalDateTime timestamp, int antall, String bilde, String kommentar);
    void updateObservation(int id, String name, animal art, Lokasjon lokasjon, LocalDateTime timestamp, int antall, String bilde, String kommentar);
    void deleteObservation(int id);

}

