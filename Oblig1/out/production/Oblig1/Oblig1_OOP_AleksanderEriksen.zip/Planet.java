public class Planet{

		private String name;
		private double radius;
		private double grav;

	public Planet(String name, double radius, double grav){
		this.name = name;
		this.radius = radius;                           //Konstruktøren
		this.grav = grav;
		}
	public void setname(String name){
		this.name = name;                        //Om vi ønsker at objektet skal bytte navn
		}
	public void setrad(double radius){
		this.radius = radius;                  //Bytte radius
		}
	public void setgrav(double grav){
		this.grav = grav;                   //Bytte gravitasjon
	}
		public String getname(){
			return name;                   //Kaller navnet til objektet
			}
		public double getrad(){           // Kaller radiusen
			return radius;
			}
		public double getgrav(){          // Kaller gravitasjonen
			return grav;
			}
	public static void main(String[] args){

	}
}
