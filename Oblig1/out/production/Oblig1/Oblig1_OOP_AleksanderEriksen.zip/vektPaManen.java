public class vektPaManen{
	public static void main(String[] args){
	int vekt = 69;
	double gravMane = 0.165;  // Lager et helttall variabel(int) og en desimaltall(double).

	System.out.println("Min vekt pa manen er " + vekt*gravMane + "Kg"); //Printer ut den multipliserte verdien av de to variablene ved bruk av variabelnavnet vi har laget.
}

}
