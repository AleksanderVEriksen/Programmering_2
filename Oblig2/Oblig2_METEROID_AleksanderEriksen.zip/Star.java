public class Star {
    private String name;
    private double radius;
    private double mass;
    private float effectiveTemp;

    public Star(String name, double radius, double mass, float effectiveTemp) {
        this.name = name;
        this.radius = radius;
        this.mass = mass;
        this.effectiveTemp = effectiveTemp;
    }
    public double getMsun(){
        double Msun = 1.98892*Math.pow(10,30);
        return mass/Msun;                       //Deler vanlig enhet på massen for å få Msun.
    }
    public double getRsun(){
        double Rsun = 695700;                 //Deler vanlig enhet(km) med rad(km) for å få Rsun.
        return radius/Rsun;
    }
    @Override
    public String toString() {
        return "Name: " + name + " " +
               "Radius: " + radius + "km" + " " +    //Overrider toString metoden slik at den viser relevant informasjon istede for hvor den befinner seg, type etc.
               "Mass: " + mass + "kg" + " " +
                "Temp: " + effectiveTemp + "C";
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setRad(double radius) {
        this.radius = radius;
    }

    public double getRadius() {
        return radius;
    }

    public void setMass(double mass) {
        this.mass = mass;                                   //Innkapsling
    }

    public double getMass() {
        return mass;
    }

    public void setTemp(float effectiveTemp) {
        this.effectiveTemp = effectiveTemp;
    }

    public float getTemp() {
        return effectiveTemp;
    }
}