class Planet{
private String name;
private double radius;
private double mass;
public Planet(String name, double mass, double radius){
        this.name = name;
        this.radius = radius;
        this.mass = mass;
        }



public double Mearth(){
        double mth = 5.972*Math.pow(10,24);
        return mass/mth;
}
public double Rearth(){
        double rth = 6371;
        return radius/rth;
}

@Override
public String toString(){
        return "Name: " + name + " " +
                "Radius: " + radius + "km" + " " +    //Overrider toString metoden slik at den viser relevant informasjon istede for hvor den befinner seg, type etc.
                "Mass: " + mass + "kg";
        }

        public double getMjup(){
                double Mjup = 1.898*Math.pow(10,27);
                return mass/Mjup;
        }
        public double getRjup(){
                double Rjup = 71492;
                return radius/Rjup;
        }
public double  surfaceGravity(){
        double  g = 0.00000000006674;
        double convRad = radius*1000;     //Konvertere radius til meter
        return (g*mass)/Math.pow(convRad,2); //g ganger massen delt på convRad^2
}
public void setName(String name){
        this.name = name;
        }
public String getName(){
        return name;
        }
public void setRad(double radius){
        this.radius = radius;
        }
public double getRadius(){
        return radius;
        }
public void setMass(double mass){
        this.mass = mass;
        }
public double getMass(){
        return mass;
        }
}
